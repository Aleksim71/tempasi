Tempasi – OUTBOX snapshot

Repository root: /home/aleksim/tempasi

Included artifacts:
 - root/changes.patch          – git diff (unstaged + staged)
 - root/bundle.tgz            – latest bundle from artifacts/bundles/
 - root/changed_files/        – current changed files (structure preserved)
 - root/README.txt            – this file

Changed files (staged + unstaged) at build time:
 - scripts/build-outbox.sh
 - src/modules/orders/orders.repo.cjs
 - src/modules/orders/orders.service.cjs
 - src/server/catalog/templates.repo.js
 - src/web/modules/analytics/analytics.cabinet.service.cjs
 - src/web/views/partials/space-my-templates.hbs

How to apply patch:
  1) Place OUTBOX.zip at repo root (or open it).
  2) Unzip: unzip OUTBOX.zip
  3) From repo root: git apply root/changes.patch

If Analytics cabinet page is part of this snapshot:
  - Open after auth: /cabinet/my-templates/analytics
  - Example: /cabinet/my-templates/analytics?sort=total_revenue&dir=desc
  - Supported sort keys (query param ?sort=):
      created_at, deleted_at, rent_count, rent_revenue, buy_revenue, total_revenue, last_order_at
  - Sort direction (query param ?dir=): asc | desc (desc by default if invalid/missing)

Tests & lint status (from scripts/death-to-routine.bundle.sh --tests --lint):
  - tests: FAIL (see bundle logs or artifacts/runs/* if present)
  - lint : OK (see bundle logs for details)
URL smoke check:
  - status: SERVER_START_TIMEOUT
  - log   : artifacts/tmp/url_smoke_check.txt (included in OUTBOX)

Note:
  - If tests fail due to missing env (e.g., DATABASE_URL_TEST),
    configure the environment and re-run tests manually:
      npm test
      npm run lint
