// src/web/routes/templates.routes.js
import { Router } from 'express';
import * as repo from '../../server/catalog/templates.repo.js';

/**
 * This router MUST NOT crash the whole page rendering.
 * In tests / CI we prefer to show an empty catalog rather than HTTP 500
 * caused by repo export/interop issues.
 */

function isFn(v) {
  return typeof v === 'function';
}

function pickCatalogFnSafe() {
  try {
    // 1) Named exports
    if (isFn(repo.selectTemplatesForCatalog)) return repo.selectTemplatesForCatalog;
    if (isFn(repo.getTemplatesCatalog)) return repo.getTemplatesCatalog;

    // 2) Default export (common pattern: export default { ... })
    if (repo.default && isFn(repo.default.selectTemplatesForCatalog)) {
      return repo.default.selectTemplatesForCatalog;
    }
    if (repo.default && isFn(repo.default.getTemplatesCatalog)) {
      return repo.default.getTemplatesCatalog;
    }

    const available = Object.keys(repo).sort().join(', ');
    console.warn(
      `[templates.routes] Catalog function not found in templates.repo.js. ` +
        `Expected selectTemplatesForCatalog or getTemplatesCatalog. Available exports: ${available}. ` +
        `Falling back to empty catalog.`,
    );

    // ✅ fail-safe fallback
    return async function getEmptyCatalog() {
      return [];
    };
  } catch (e) {
    console.warn(
      `[templates.routes] Failed to pick catalog function: ${String(e?.message || e)}. ` +
        `Falling back to empty catalog.`,
    );
    return async function getEmptyCatalog() {
      return [];
    };
  }
}

function pickBySlugFnSafe() {
  try {
    // Named exports (preferred)
    if (isFn(repo.getTemplateBySlug)) return repo.getTemplateBySlug;
    if (isFn(repo.selectTemplateBySlug)) return repo.selectTemplateBySlug;
    if (isFn(repo.findTemplateBySlug)) return repo.findTemplateBySlug;

    // Default export variants
    if (repo.default && isFn(repo.default.getTemplateBySlug)) return repo.default.getTemplateBySlug;
    if (repo.default && isFn(repo.default.selectTemplateBySlug))
      return repo.default.selectTemplateBySlug;
    if (repo.default && isFn(repo.default.findTemplateBySlug))
      return repo.default.findTemplateBySlug;

    // No slug function is OK (we have fallback: load catalog + find)
    return null;
  } catch (e) {
    console.warn(
      `[templates.routes] Failed to pick by-slug function: ${String(e?.message || e)}. ` +
        `Falling back to catalog-scan by slug.`,
    );
    return null;
  }
}

function toStr(v) {
  return v == null ? '' : String(v);
}

function toEpochMs(v) {
  if (!v) return '';
  const d = v instanceof Date ? v : new Date(v);
  const n = d.getTime();
  return Number.isFinite(n) ? String(n) : '';
}

function normalizeTemplate(raw, slugFromUrl) {
  const meta = raw?.meta || raw?.metadata || raw?.data || raw || {};

  // id can be numeric or string; keep string for URLs
  const id = toStr(raw?.id || meta?.id).trim();

  const slug = toStr(raw?.slug || raw?.id || meta?.slug || slugFromUrl).trim();
  const title =
    toStr(raw?.title).trim() ||
    toStr(raw?.name).trim() ||
    toStr(meta?.title).trim() ||
    toStr(meta?.name).trim() ||
    slug;

  // ✅ Preview (MVP): deterministic local path
  // Stored at: public/uploads/previews/<templateId>.png
  // Served as: /uploads/previews/<templateId>.png
  // Add cache-buster so after ZIP replace browser doesn't keep old image
  const updatedAt =
    raw?.updated_at || raw?.updatedAt || meta?.updated_at || meta?.updatedAt || null;
  const v = toEpochMs(updatedAt);

  const deterministicPreview = id
    ? `/uploads/previews/${encodeURIComponent(id)}.png${v ? `?v=${v}` : ''}`
    : '';

  const previewUrl =
    toStr(raw?.previewUrl).trim() ||
    toStr(meta?.previewUrl).trim() ||
    toStr(meta?.preview).trim() ||
    deterministicPreview ||
    `/t/${slug}/preview.png`;

  // Demo: allow explicit demoUrl, fallback to internal live preview endpoint
  const demoUrl = toStr(raw?.demoUrl || meta?.demoUrl).trim() || '';

  // Prices: support both legacy {price, currency} and contract {prices:{buy,rent}}
  const prices = raw?.prices || meta?.prices;
  const legacyPrice = raw?.price ?? meta?.price ?? '';
  const legacyCurrency = toStr(raw?.currency || meta?.currency || 'EUR').trim() || 'EUR';

  const buy = prices?.buy
    ? {
        amount: prices.buy.amount,
        currency: toStr(prices.buy.currency || legacyCurrency || 'EUR'),
      }
    : legacyPrice !== ''
      ? {
          amount: legacyPrice,
          currency: legacyCurrency,
        }
      : null;

  const rent = prices?.rent
    ? {
        amount: prices.rent.amount,
        currency: toStr(prices.rent.currency || legacyCurrency || 'EUR'),
        period: toStr(prices.rent.period || 'mo'),
      }
    : null;

  // Zip flag: support different shapes
  const hasZip =
    Boolean(raw?.hasZip) ||
    Boolean(raw?.zipReady) ||
    Boolean(meta?.hasZip) ||
    Boolean(meta?.zipReady);

  // Other info
  const category = toStr(raw?.category || meta?.category).trim() || '';
  const license = toStr(raw?.license || meta?.license).trim() || '';
  const type = toStr(raw?.type || meta?.type).trim() || '';
  const version = toStr(raw?.version || meta?.version).trim() || '';

  const description =
    toStr(raw?.description).trim() ||
    toStr(meta?.description).trim() ||
    toStr(meta?.excerpt).trim() ||
    '';

  const longDescription =
    toStr(raw?.longDescription).trim() || toStr(meta?.longDescription).trim() || '';

  const tech = Array.isArray(raw?.tech) ? raw.tech : Array.isArray(meta?.tech) ? meta.tech : null;

  const author = raw?.author || meta?.author || null;

  const features = Array.isArray(raw?.features)
    ? raw.features
    : Array.isArray(meta?.features)
      ? meta.features
      : null;

  const isSold =
    Boolean(raw?.isSold) ||
    Boolean(raw?.is_sold) ||
    Boolean(meta?.isSold) ||
    Boolean(meta?.is_sold);

  const soldAt =
    raw?.soldAt || raw?.sold_at || meta?.soldAt || meta?.sold_at || null;

  return {
    id,
    slug,
    title,
    category,
    license,
    type,
    version,
    description,
    longDescription,
    tech,
    author,
    features,
    previewUrl,
    demoUrl,
    prices: {
      buy,
      rent,
    },
    // legacy fields (some older pages may still use them)
    price: legacyPrice !== '' ? legacyPrice : buy ? buy.amount : '',
    currency: legacyCurrency,
    hasZip,
    isSold,
    soldAt,
  };
}

export function createTemplatesRouter() {
  const router = Router();

  const selectCatalog = pickCatalogFnSafe();
  const getBySlug = pickBySlugFnSafe();

  // /templates — catalog
  router.get('/', async (req, res, next) => {
    try {
      const db = req.app.locals?.db;

      // Some repo functions accept db; some don't.
      const rawList = await (selectCatalog.length >= 1 ? selectCatalog(db) : selectCatalog());

      // ✅ normalize previewUrl + compat fields for cards
      const templates = (rawList || []).map((t) => normalizeTemplate(t));

      res.render('pages/templates/index', {
        title: 'Templates — Tempasi',
        bodyClass: 'templates-page',
        activePage: 'templates',
        styles: ['/css/pages/catalog.css', '/css/pages/templates.css'],
        templates,
      });
    } catch (err) {
      // ✅ Hard fail-safe: never 500 for catalog
      console.warn(
        `[templates.routes] GET /templates failed: ${String(err?.message || err)}. Rendering empty catalog.`,
      );
      try {
        return res.status(200).render('pages/templates/index', {
          title: 'Templates — Tempasi',
          bodyClass: 'templates-page',
          activePage: 'templates',
          styles: ['/css/pages/catalog.css', '/css/pages/templates.css'],
          templates: [],
        });
      } catch (e2) {
        return next(e2);
      }
    }
  });

  // /templates/:slug — details page
  router.get('/:slug', async (req, res, next) => {
    try {
      const slug = toStr(req.params.slug).trim();
      const db = req.app.locals?.db;

      let raw = null;

      // Prefer direct repo function if present
      if (getBySlug) {
        raw = await (getBySlug.length >= 2 ? getBySlug(db, slug) : getBySlug(slug));
      } else {
        // Fallback: load catalog and find
        const list = await (selectCatalog.length >= 1 ? selectCatalog(db) : selectCatalog());
        raw = (list || []).find((t) => t?.slug === slug || t?.id === slug) || null;
      }

      if (!raw) {
        return res.status(404).render('pages/template-not-found', {
          title: 'Template not found — Tempasi',
          bodyClass: 'page-template-details',
          activePage: 'templates',
          styles: ['/css/pages/template-details.css'],
          slug,
        });
      }

      const template = normalizeTemplate(raw, slug);

      return res.status(200).render('pages/template-details', {
        title: `${template.title} — Tempasi`,
        bodyClass: 'page-template-details',
        activePage: 'templates',
        styles: ['/css/pages/template-details.css'],
        template,
      });
    } catch (err) {
      return next(err);
    }
  });

  return router;
}
